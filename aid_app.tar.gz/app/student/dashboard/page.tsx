import StudentDashboard from '@/components/dashboard/StudentDashboard'

export default function StudentDashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <StudentDashboard />
    </div>
  )
}
