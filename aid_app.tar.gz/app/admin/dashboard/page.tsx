import AdminDashboard from '@/components/dashboard/AdminDashboard'

export default function AdminDashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <AdminDashboard />
    </div>
  )
}
